package com.example.pos_system;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PosSystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
